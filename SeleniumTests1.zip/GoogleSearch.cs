﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.Extensions;

namespace SeleniumTests1
{
    [TestClass]
    public class Geoforum
    {
        [TestMethod]
        public void TestMethod1()
        {
            ChromeOptions options = SeleniumTestHelpLibrary.GetChromeOptions();

            using (var driver = new ChromeDriver(options))
            {
                driver.Manage().Window.Maximize();
                driver.Navigate().GoToUrl("https://geoforum.pl");
                var searchBox = driver.FindElementById("keyword");
                searchBox.SendKeys("test");
                var searchButton = driver.FindElementById("search_button");
                searchButton.Submit();
                //var searchResults = driver.FindElementById("search_button");
                SeleniumTestHelpLibrary.TakeScreenshot(driver);
            }
        }
    }
}
